package com.example.sop64070125;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Sop64070125ApplicationTests {

    @Test
    void contextLoads() {
    }

}
