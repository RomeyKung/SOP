package com.example.sop64070125;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Sop64070125Application {

    public static void main(String[] args) {
        SpringApplication.run(Sop64070125Application.class, args);
    }

}
